n=50
k=4
sqpe=5
pose=4