n=300
k=8
sqpe=30
pose=8