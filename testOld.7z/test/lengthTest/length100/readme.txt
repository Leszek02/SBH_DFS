n=100
k=5
sqpe=10
pose=5