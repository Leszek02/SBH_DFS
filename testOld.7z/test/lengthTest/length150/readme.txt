n=150
k=6
sqpe=15
pose=6