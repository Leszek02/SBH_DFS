n=1000
k=10
sqpe=100
pose=18