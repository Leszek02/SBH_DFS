n=500
k=10
pose=10