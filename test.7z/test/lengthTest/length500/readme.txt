n=500
k=10
sqpe=50
pose=100