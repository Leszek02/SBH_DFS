n=750
k=10
sqpe=75
pose=150